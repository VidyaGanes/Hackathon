import streamlit as st
from transformers import pipeline
from docx import Document


# Function to extract text from a Word document
def extract_text_from_docx(docx_path):
    doc = Document(docx_path)
    text = []
    for paragraph in doc.paragraphs:
        text.append(paragraph.text)
    return '\n\n'.join(text)


# Initialize the Streamlit app
@st.cache_data()
def load_text_generation_model():
    try:
        # Load a text generation model (e.g., GPT-2 or any other available model)
        generator = pipeline("text-generation", model="gpt2")
        return generator
    except Exception as e:
        st.error(f"Error loading model: {e}")
        return None


def main():
    st.title('Text Generation Application')

    # Load the text generation model
    genai_model = load_text_generation_model()

    if genai_model is None:
        return  # Exit if model loading fails

    # Extract text from the Word document
    input_text = extract_text_from_docx('hackathon_input.docx')

    # Input prompt
    prompt = st.text_area('Enter your prompt:', '')

    if st.button('Generate Response'):
        if prompt:
            # Generate response using the text generation model
            response = genai_model(prompt, max_length=150)[0]['generated_text']

            # Display response
            st.markdown(f'**Response:** \n{response}')


if __name__ == '__main__':
    main()
