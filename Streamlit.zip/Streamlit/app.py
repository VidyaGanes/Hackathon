from docx import Document
import streamlit as st
from transformers import pipeline, set_seed
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from scipy.sparse import csr_matrix


# Function to extract text from a Word document
def extract_text_from_docx(docx_path):
    doc = Document(docx_path)
    text = []
    for paragraph in doc.paragraphs:
        text.append(paragraph.text)
    return '\n\n'.join(text)


# Function to split text into chunks
def chunk_text(text, chunk_size=500):
    chunks = []
    words = text.split()
    current_chunk = []
    current_length = 0

    for word in words:
        if current_length + len(word) < chunk_size:
            current_chunk.append(word)
            current_length += len(word) + 1  # +1 for the space
        else:
            chunks.append(' '.join(current_chunk))
            current_chunk = [word]
            current_length = len(word)

    if current_chunk:
        chunks.append(' '.join(current_chunk))

    return chunks


# Initialize the Streamlit app
@st.cache_data
def load_model():
    set_seed(42)
    return pipeline("text-generation", model="distilgpt2")


# Function to find relevant chunk based on prompt
@st.cache_data(hash_funcs={TfidfVectorizer: id, csr_matrix: lambda _: None})
def find_relevant_chunk(prompt, vectorizer, _chunk_vectors, text_chunks):
    # Ensure prompt is in the same format as text_chunks for vectorization
    prompt_chunks = chunk_text(prompt)
    combined_chunks = text_chunks + prompt_chunks

    # Vectorize combined chunks
    combined_vectors = vectorizer.fit_transform(combined_chunks)
    prompt_vector = combined_vectors[-1]  # Last vector corresponds to the prompt

    chunk_vectors = combined_vectors[:-1]  # Exclude the prompt vector
    chunk_scores = cosine_similarity(prompt_vector, chunk_vectors).flatten()

    # Sort chunks by score and select the highest scoring chunk
    sorted_indices = np.argsort(chunk_scores)[::-1]  # Sort in descending order
    max_score_index = sorted_indices[0]  # Select the chunk with highest score

    # If the highest score is below a threshold, return None (no relevant chunk found)
    if chunk_scores[max_score_index] < 0.001:  # Adjust threshold as needed
        return None

    return text_chunks[max_score_index]


# Function to generate response based on relevant chunk
def generate_response(prompt, relevant_chunk, genai_model, max_length=200):
    if relevant_chunk is None:
        return "Sorry, I couldn't find relevant information in the document for your prompt."

    # Combine prompt and relevant chunk for GPT-2 input
    input_text = f"{prompt}\n\nContext: {relevant_chunk}"

    # Generate response using GPT-2 model
    generated_text = genai_model(input_text, max_length=max_length, do_sample=True)[0]['generated_text']
    return generated_text


def main():
    st.title('Overgoods: AI Powered')
    st.markdown("""
    Generates responses based on prompts using the Gemini model.
    """)

    # Load the model
    genai_model = load_model()

    # Extract text from the Word document
    input_text = extract_text_from_docx('hackathon_input.docx')
    text_chunks = chunk_text(input_text)

    # Vectorize chunks for cosine similarity
    vectorizer = TfidfVectorizer(stop_words='english')
    chunk_vectors = vectorizer.fit_transform(text_chunks)

    # Input prompt
    prompt = st.text_area('Enter your prompt:', '')

    if st.button('Generate Response'):
        if prompt:
            # Find the most relevant chunk based on the prompt
            relevant_chunk = find_relevant_chunk(prompt, vectorizer, chunk_vectors, text_chunks)

            # Generate response based on the prompt and relevant chunk
            response = generate_response(prompt, relevant_chunk, genai_model)

            # Display response
            st.markdown(f'**Response:** \n{response}')


if __name__ == '__main__':
    main()