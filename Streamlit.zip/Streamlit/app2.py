from docx import Document
import streamlit as st
from transformers import pipeline, set_seed
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# Function to extract text from a Word document
def extract_text_from_docx(docx_path):
    doc = Document(docx_path)
    text = [paragraph.text for paragraph in doc.paragraphs if paragraph.text]
    return '\n\n'.join(text)

# Function to split text into chunks
def chunk_text(text, chunk_size=500):
    chunks = []
    words = text.split()
    current_chunk = []
    current_length = 0

    for word in words:
        if current_length + len(word) < chunk_size:
            current_chunk.append(word)
            current_length += len(word) + 1  # +1 for the space
        else:
            chunks.append(' '.join(current_chunk))
            current_chunk = [word]
            current_length = len(word)

    if current_chunk:
        chunks.append(' '.join(current_chunk))

    return chunks

# Initialize the Streamlit app
@st.cache_resource
def load_model():
    set_seed(42)
    return pipeline("text-generation", model="distilgpt2")

# Function to find relevant chunk based on prompt
@st.cache_data
def find_relevant_chunk(prompt, vectorizer, text_chunks):
    combined_chunks = text_chunks + [prompt]
    combined_vectors = vectorizer.fit_transform(combined_chunks)

    prompt_vector = combined_vectors[-1]  # Last vector is the prompt
    chunk_vectors = combined_vectors[:-1]  # Exclude the prompt vector
    chunk_scores = cosine_similarity(prompt_vector, chunk_vectors).flatten()

    sorted_indices = np.argsort(chunk_scores)[::-1]  # Sort in descending order
    max_score_index = sorted_indices[0]

    # Adjust threshold for relevance
    if chunk_scores[max_score_index] < 0.3:  # Lower threshold for inclusiveness
        return None

    return text_chunks[max_score_index]

# Function to generate a concise response based on relevant chunk
def generate_response(prompt, relevant_chunk, genai_model):
    if relevant_chunk is None:
        return "Sorry, I couldn't find relevant information in the document for your prompt."

    # Combine prompt and relevant chunk for input
    input_text = f"{prompt}\n\nContext: {relevant_chunk}"

    # Generate response using the model
    generated_text = genai_model(input_text, max_length=50, do_sample=True)[0]['generated_text']

    # Trim to two lines
    response_lines = generated_text.splitlines()
    return "\n".join(response_lines[:2])  # Return only the first two lines

def main():
    st.title('Lost and Found: GenAI Application')
    st.markdown("""
    This web app generates responses based on prompts using relevant context from a document.
    """)

    # Load the model
    genai_model = load_model()

    # Extract text from the Word document
    input_text = extract_text_from_docx('hackathon_input.docx')
    text_chunks = chunk_text(input_text)

    # Vectorize chunks for cosine similarity
    vectorizer = TfidfVectorizer(stop_words='english')
    vectorizer.fit(text_chunks)  # Fit only once on text chunks

    # Input prompt
    prompt = st.text_area('Enter your prompt:', '')

    if st.button('Generate Response'):
        if prompt:
            # Find the most relevant chunk based on the prompt
            relevant_chunk = find_relevant_chunk(prompt, vectorizer, text_chunks)

            # Generate response based on the prompt and relevant chunk
            response = generate_response(prompt, relevant_chunk, genai_model)

            # Display response
            st.markdown(f'**Response:** \n{response}')
        else:
            st.warning("Please enter a prompt.")

if __name__ == '__main__':
    main()